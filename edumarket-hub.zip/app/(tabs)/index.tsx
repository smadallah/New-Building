import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { ScreenContainer } from "@/components/screen-container";

export default function HomeScreen() {
  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1 gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-4xl font-bold text-foreground">
              EduMarket Hub
            </Text>
            <Text className="text-base text-muted">
              Learn, teach, and trade educational resources
            </Text>
          </View>

          {/* Featured Courses Section */}
          <View className="gap-3">
            <Text className="text-xl font-semibold text-foreground">
              Featured Courses
            </Text>
            <View className="bg-surface rounded-2xl p-4 border border-border">
              <Text className="text-sm font-medium text-primary mb-1">
                Mathematics 101
              </Text>
              <Text className="text-xs text-muted mb-3">
                Master algebra and geometry fundamentals
              </Text>
              <TouchableOpacity className="bg-primary px-4 py-2 rounded-lg self-start">
                <Text className="text-white text-sm font-semibold">
                  Explore Course
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Marketplace Highlights */}
          <View className="gap-3">
            <Text className="text-xl font-semibold text-foreground">
              Trending Materials
            </Text>
            <View className="bg-surface rounded-2xl p-4 border border-border">
              <Text className="text-sm font-medium text-primary mb-1">
                Biology Study Notes
              </Text>
              <Text className="text-xs text-muted mb-3">
                Comprehensive notes for high school biology
              </Text>
              <TouchableOpacity className="bg-primary px-4 py-2 rounded-lg self-start">
                <Text className="text-white text-sm font-semibold">
                  View Details
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Quick Actions */}
          <View className="gap-3">
            <Text className="text-xl font-semibold text-foreground">
              Quick Actions
            </Text>
            <View className="flex-row gap-3">
              <TouchableOpacity className="flex-1 bg-primary rounded-xl p-4 items-center">
                <Text className="text-white font-semibold text-sm">
                  Find Tutor
                </Text>
              </TouchableOpacity>
              <TouchableOpacity className="flex-1 bg-primary rounded-xl p-4 items-center">
                <Text className="text-white font-semibold text-sm">
                  Sell Materials
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Info Card */}
          <View className="bg-surface rounded-2xl p-4 border border-border">
            <Text className="text-sm font-semibold text-foreground mb-2">
              Welcome to EduMarket Hub
            </Text>
            <Text className="text-xs text-muted leading-relaxed">
              Connect with educators, access quality learning materials, and grow your knowledge. Start exploring today!
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
