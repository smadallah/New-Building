import { ScrollView, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";

export default function ExploreScreen() {
  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        <View className="flex-1 gap-4">
          <Text className="text-3xl font-bold text-foreground">Explore</Text>
          <Text className="text-base text-muted">
            Browse courses, tutors, and educational resources
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
